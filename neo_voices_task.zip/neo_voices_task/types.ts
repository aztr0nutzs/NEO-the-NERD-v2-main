import type { AccentColor } from "@/lib/types"

export type VoiceCategory =
  | "Core NEO voices"
  | "Warm assistants"
  | "Comic voices"
  | "Robotic / synthetic voices"
  | "Narrator / announcer voices"
  | "Retro / arcade voices"
  | "Dramatic / villainous voices"
  | "Energetic / hype voices"
  | "Calm / reflective voices"

export type VoiceAvailability =
  | "profile-only"
  | "browser-preview"
  | "provider-ready"
  | "future-provider-target"
  | "unavailable"

export type VoiceToneProfile =
  | "balanced"
  | "energetic"
  | "calm"
  | "robotic"
  | "aggressive"
  | "sarcastic"
  | "dramatic"
  | "retro"
  | "playful"

/**
 * Honest taxonomy of *where the uniqueness of this voice comes from*.
 *
 *   provider-distinct  → owns a real provider voice ID; the underlying engine
 *                        timbre is genuinely unique among NEO profiles.
 *   native-distinct    → bound (at runtime) to a specific Android engine voice
 *                        that is genuinely different from any other profile's
 *                        selected engine voice.
 *   styled-variant     → shares the underlying engine voice with another NEO
 *                        profile; uniqueness comes entirely from style
 *                        (pitch / rate / cadence / text shaping / instructions).
 *   profile-only       → no engine binding promised — phrasing, pitch and rate
 *                        change only, fully cosmetic without playback.
 */
export type VoiceTimbreSource =
  | "provider-distinct"
  | "native-distinct"
  | "styled-variant"
  | "profile-only"

/**
 * Coarse cadence personality used both for text shaping and as a UI badge.
 * Independent from `toneProfile` because two profiles can share a tone but
 * have very different rhythmic feel (e.g. "commander" vs "tactical-guide").
 */
export type VoiceCadenceProfile =
  | "balanced"
  | "clipped"
  | "flowing"
  | "punchy"
  | "drawn-out"
  | "staccato"
  | "lilting"
  | "deadpan"

export type VoiceFallbackBehavior =
  | "native-then-browser"
  | "browser-only"
  | "provider-only"
  | "none"

export interface VoiceProfile {
  id: string
  displayName: string
  name: string
  pitch: number
  rate: number
  toneProfile: VoiceToneProfile
  sampleText: string
  category: VoiceCategory
  shortDescription: string
  styleIdentity: string
  longDescription: string
  toneTags: string[]
  idealUseCases: string[]
  energyLevel: 1 | 2 | 3 | 4 | 5
  warmthLevel: 1 | 2 | 3 | 4 | 5
  humorLevel: 1 | 2 | 3 | 4 | 5
  roboticnessLevel: 1 | 2 | 3 | 4 | 5
  clarityLevel: 1 | 2 | 3 | 4 | 5
  /**
   * 1-5 commanding/authoritative cue — used both for text shaping (clipped
   * imperatives at high values) and for steering Android voice selection
   * (deeper / firmer voices preferred at high values).
   */
  authorityLevel: 1 | 2 | 3 | 4 | 5
  defaultSpeed: number
  defaultPitch: number
  defaultVolume: number
  recommendedEmotion: number
  compatiblePersonalities: string[]
  /** Default linked personalities for *this voice* (asymmetric companion of compatiblePersonalities). */
  recommendedPersonalities: string[]
  sampleLine: string
  cadenceHint: string
  cadenceProfile: VoiceCadenceProfile
  expressivenessLevel: 1 | 2 | 3 | 4 | 5
  featured: boolean
  providerVoiceId?: string
  /**
   * Hard-coded native Android engine voice name binding, if NEO ever ships
   * with a curated Android voice mapping. Currently always undefined — Android
   * voice selection is resolved at runtime against the engine's installed set.
   */
  nativeVoiceId?: string
  availability: VoiceAvailability
  accent: AccentColor
  /**
   * Honest uniqueness taxonomy. ALWAYS reflects what is *promised* by the
   * profile, never composed with live runtime. Use `getRuntimeTimbreSource()`
   * for the runtime-resolved value.
   */
  timbreSource: VoiceTimbreSource
  /**
   * Designed fallback path when the primary engine for this profile is
   * unavailable in the current runtime.
   */
  fallbackBehavior: VoiceFallbackBehavior
  /** 0-100 score of how genuinely distinct this profile sounds across NEO. */
  uniquenessScore: number
  /** One-sentence plain-English summary of *why* this voice sounds different. */
  uniquenessExplanation: string
  /**
   * Optional natural-language instruction passed to provider TTS engines that
   * accept an `instructions` field. Tuned per profile to push pacing, energy,
   * resonance, sharpness, warmth and theatricality contrast.
   */
  stylePrompt?: string
  /** Optional emotion sub-instruction layered on top of `stylePrompt`. */
  emotionalInstructions?: string
}

export interface VoiceFilterState {
  search: string
  category: VoiceCategory | "All"
  toneTag: string | "All"
  favoritesOnly: boolean
}
