"use client"

import { Capacitor, registerPlugin } from "@capacitor/core"
import type { VoiceParams } from "@/lib/types"
import type { VoiceProfile } from "./types"
import { buildStyledVoiceSpeech } from "./voiceStyle"

export interface NativeTtsAvailability {
  available: boolean
  ready: boolean
  platform: string
  message?: string
}

export interface NativeTtsSpeakResult {
  ok: boolean
  message?: string
  voiceName?: string | null
}

export interface AndroidNativeVoice {
  name: string
  locale: string
  quality?: number
  latency?: number
  networkConnectionRequired?: boolean
}

interface NativeTtsPlugin {
  isAvailable(): Promise<NativeTtsAvailability>
  speak(options: {
    text: string
    rate: number
    pitch: number
    volume: number
    voiceName?: string
  }): Promise<NativeTtsSpeakResult>
  getVoices(): Promise<{
    available: boolean
    voices: AndroidNativeVoice[]
    message?: string
  }>
  stop(): Promise<NativeTtsSpeakResult>
}

const neoTts = registerPlugin<NativeTtsPlugin>("NeoTts")

export function isAndroidNativeTtsRuntime(): boolean {
  return Capacitor.getPlatform() === "android"
}

export async function getAndroidNativeTtsAvailability(): Promise<NativeTtsAvailability> {
  if (!isAndroidNativeTtsRuntime()) {
    return { available: false, ready: false, platform: Capacitor.getPlatform(), message: "Not Android runtime." }
  }
  try {
    return await neoTts.isAvailable()
  } catch (error) {
    return {
      available: false,
      ready: false,
      platform: "android",
      message: error instanceof Error ? error.message : "Native Android TTS bridge unavailable.",
    }
  }
}

export async function speakWithAndroidNativeTts(options: {
  text: string
  profile: VoiceProfile
  params: VoiceParams
}): Promise<NativeTtsSpeakResult> {
  const availability = await waitForAndroidNativeTtsReady()
  if (!availability.available || !availability.ready) {
    return { ok: false, message: availability.message ?? "Android TTS engine not ready." }
  }
  const speech = buildStyledVoiceSpeech(options.profile, options.text, options.params)
  const voiceName = await selectAndroidNativeVoiceName(options.profile)
  return neoTts.speak({
    text: speech.text,
    rate: speech.rate,
    pitch: speech.pitch,
    volume: speech.volume,
    ...(voiceName ? { voiceName } : {}),
  })
}

let cachedAndroidVoices: AndroidNativeVoice[] | null = null

export function clearAndroidVoiceCache() {
  cachedAndroidVoices = null
}

export async function getAndroidNativeVoices(): Promise<AndroidNativeVoice[]> {
  if (!isAndroidNativeTtsRuntime()) return []
  if (cachedAndroidVoices) return cachedAndroidVoices
  try {
    const result = await neoTts.getVoices()
    cachedAndroidVoices = Array.isArray(result.voices) ? result.voices : []
    return cachedAndroidVoices
  } catch {
    cachedAndroidVoices = []
    return cachedAndroidVoices
  }
}

/**
 * Pick an Android engine voice that best matches the profile.
 *
 *   1. Prefer offline voices (`networkConnectionRequired === false`).
 *   2. Prefer en-* locales (en-US > en-GB > en-* > else).
 *   3. Reward voices whose name hints match the profile's authority / warmth
 *      / energy / robot levels.
 *   4. Tie-break by quality, then by a deterministic hash of the profile id
 *      so two profiles with similar levels still resolve to different voices
 *      when more than one candidate is available.
 *
 * Returns null when the engine reports zero usable voices — at which point
 * the runtime cannot promise distinct timbres and the profile must be treated
 * as a styled variant.
 */
export async function selectAndroidNativeVoiceName(profile: VoiceProfile): Promise<string | null> {
  const voices = await getAndroidNativeVoices()
  if (!voices.length) return null

  const candidates = voices
    .filter((voice) => !voice.networkConnectionRequired)
    .filter((voice) => voice.locale?.toLowerCase().startsWith("en"))
    .map((voice) => ({ voice, score: scoreVoiceMatch(voice, profile) }))
    .sort((a, b) => {
      if (b.score !== a.score) return b.score - a.score
      const quality = (b.voice.quality ?? 0) - (a.voice.quality ?? 0)
      if (quality !== 0) return quality
      return a.voice.name.localeCompare(b.voice.name)
    })

  if (!candidates.length) return null

  // Among the top-scoring candidates, deterministically rotate by profile id
  // so two profiles asking for the same hint group end up on different voices
  // when the device offers multiple equivalents.
  const topScore = candidates[0].score
  const topTier = candidates.filter((entry) => entry.score === topScore)
  const rotation = topTier.length > 1
    ? Math.abs(hashString(profile.id)) % topTier.length
    : 0
  return topTier[rotation]?.voice.name ?? null
}

function scoreVoiceMatch(voice: AndroidNativeVoice, profile: VoiceProfile) {
  let score = 0
  const lower = voice.name.toLowerCase()
  const locale = voice.locale?.toLowerCase() ?? ""

  if (locale === "en-us") score += 4
  else if (locale.startsWith("en-")) score += 2

  // Authority / warmth signal — Android voice names commonly include 'male'
  // / 'female' / locale-named voices. Use them as soft hints, not certainty.
  const wantsDeep = profile.authorityLevel >= 4 && profile.warmthLevel <= 3
  const wantsWarm = profile.warmthLevel >= 4
  const wantsBright = profile.energyLevel >= 4 && profile.warmthLevel >= 3
  const wantsTiny = profile.energyLevel >= 4 && profile.warmthLevel <= 3 && profile.defaultPitch >= 70

  if (wantsDeep && (lower.includes("male") || lower.includes("daniel") || lower.includes("david") || lower.includes("brian"))) score += 5
  if (wantsWarm && (lower.includes("female") || lower.includes("samantha") || lower.includes("aria") || lower.includes("ava"))) score += 5
  if (wantsBright && (lower.includes("female") || lower.includes("nova") || lower.includes("zira") || lower.includes("emma"))) score += 4
  if (wantsTiny && (lower.includes("female") || lower.includes("network") || lower.includes("high") || lower.includes("sprite"))) score += 3

  if (profile.roboticnessLevel >= 4 && lower.includes("network")) score += 1

  // Reward higher quality voices.
  if ((voice.quality ?? 0) >= 400) score += 1

  return score
}

function hashString(value: string) {
  let hash = 0
  for (let i = 0; i < value.length; i += 1) {
    hash = (hash * 31 + value.charCodeAt(i)) | 0
  }
  return hash
}

async function waitForAndroidNativeTtsReady(
  attempts = 6,
  intervalMs = 250,
): Promise<NativeTtsAvailability> {
  let last: NativeTtsAvailability = await getAndroidNativeTtsAvailability()
  if (last.available && last.ready) return last
  for (let i = 1; i < attempts; i += 1) {
    await new Promise((resolve) => setTimeout(resolve, intervalMs))
    last = await getAndroidNativeTtsAvailability()
    if (last.available && last.ready) return last
  }
  return last
}

export async function stopAndroidNativeTts(): Promise<boolean> {
  if (!isAndroidNativeTtsRuntime()) return false
  try {
    const result = await neoTts.stop()
    return Boolean(result.ok)
  } catch {
    return false
  }
}
