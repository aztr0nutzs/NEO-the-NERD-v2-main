/**
 * User-facing label describing how the current voice profile will actually be
 * previewed in the current runtime. Strictly truthful: it composes both the
 * profile's intrinsic availability AND the live runtime capabilities. Uses
 * the new timbre-source taxonomy so labels never overclaim uniqueness.
 */
export function getProfileTruthLabel(
  profile: VoiceProfile,
  capabilities: VoiceRuntimeCapabilities,
): string {
  if (profile.availability === "unavailable") return "PREVIEW UNAVAILABLE"

  if (profile.availability === "provider-ready") {
    if (capabilities.providerTtsAvailable) {
      return profile.timbreSource === "provider-distinct"
        ? "Unique Provider Timbre"
        : "Styled Variant (Provider)"
    }
    if (capabilities.nativeAndroidTtsAvailable) {
      const base =
        capabilities.selectedAndroidVoiceName && capabilities.nativeAndroidVoiceCount > 1
          ? `Android Device Voice (${capabilities.selectedAndroidVoiceName})`
          : "Styled Android TTS"
      return `${base} // styled fallback`
    }
    if (capabilities.browserSpeechSupported) return "Browser Speech (Styled Fallback)"
    return "PROVIDER MAPPED // NO LOCAL FALLBACK"
  }

  if (profile.availability === "browser-preview") {
    if (capabilities.nativeAndroidTtsAvailable) return "Styled Android TTS"
    return capabilities.browserSpeechSupported
      ? "Browser Speech (Styled)"
      : "BROWSER PREVIEW UNAVAILABLE"
  }

  if (profile.availability === "future-provider-target") {
    if (capabilities.nativeAndroidTtsAvailable) return "Styled Android TTS // provider pending"
    return capabilities.browserSpeechSupported
      ? "Browser Speech (Styled) // provider pending"
      : "FUTURE PROVIDER TARGET"
  }

  if (profile.availability === "profile-only") {
    if (capabilities.nativeAndroidTtsAvailable) return "Styled Android TTS // profile-only"
    return capabilities.browserSpeechSupported
      ? "Browser Speech (Styled) // profile-only"
      : "Profile-only / no engine binding"
  }

  return "PREVIEW UNAVAILABLE"
}
