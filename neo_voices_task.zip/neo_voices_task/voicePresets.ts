import type { VoiceParams } from "@/lib/types"
import type { VoiceProfile } from "./types"
import { getVoiceProfile } from "./voiceProfiles"

export function voiceProfileToParams(voiceId: string): VoiceParams {
  const profile = getVoiceProfile(voiceId)
  return {
    speed: Math.round(((profile.rate - 0.7) / 0.7) * 100),
    pitch: Math.round(((profile.pitch - 0.6) / 1.0) * 100),
    volume: profile.defaultVolume,
    emotion: profile.recommendedEmotion,
  }
}

/**
 * Static badge for a profile — safe to render without runtime data.
 *
 * Combines the legacy `availability` axis with the new `timbreSource` taxonomy
 * so the same call site can still ask for a one-line static badge. For the
 * full runtime-aware label, callers should compose this with
 * `getProfileTruthLabel` from `voice-runtime.ts`.
 */
export function availabilityLabel(availability: VoiceProfile["availability"]) {
  switch (availability) {
    case "provider-ready":
      return "PROVIDER MAPPED"
    case "browser-preview":
      return "BROWSER PREVIEW"
    case "future-provider-target":
      return "FUTURE PROVIDER TARGET"
    case "profile-only":
      return "PROFILE-ONLY"
    default:
      return "UNAVAILABLE"
  }
}

/**
 * Static badge for the *timbre* claim made by this profile (independent of
 * the current runtime).
 */
export function timbreSourceLabel(profile: VoiceProfile) {
  switch (profile.timbreSource) {
    case "provider-distinct":
      return "UNIQUE TIMBRE · PROVIDER"
    case "native-distinct":
      return "UNIQUE TIMBRE · DEVICE"
    case "styled-variant":
      return "STYLED VARIANT"
    case "profile-only":
      return "PROFILE ONLY"
    default:
      return "UNAVAILABLE"
  }
}
