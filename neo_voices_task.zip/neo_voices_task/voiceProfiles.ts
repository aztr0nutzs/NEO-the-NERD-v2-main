import type {
  VoiceCadenceProfile,
  VoiceFallbackBehavior,
  VoiceProfile,
  VoiceTimbreSource,
  VoiceToneProfile,
} from "./types"

interface ProfileSeed {
  id: string
  name: string
  category: VoiceProfile["category"]
  shortDescription: string
  longDescription: string
  toneTags: string[]
  idealUseCases: string[]
  energyLevel: VoiceProfile["energyLevel"]
  warmthLevel: VoiceProfile["warmthLevel"]
  humorLevel: VoiceProfile["humorLevel"]
  roboticnessLevel: VoiceProfile["roboticnessLevel"]
  clarityLevel: VoiceProfile["clarityLevel"]
  authorityLevel: VoiceProfile["authorityLevel"]
  defaultSpeed: number
  defaultPitch: number
  defaultVolume: number
  recommendedEmotion: number
  compatiblePersonalities: string[]
  recommendedPersonalities: string[]
  sampleLine: string
  featured: boolean
  providerVoiceId?: string
  availability: VoiceProfile["availability"]
  accent: VoiceProfile["accent"]
  /**
   * Honest timbre taxonomy. The first profile pinned to a given providerVoiceId
   * is the canonical "provider-distinct" owner; every other profile sharing
   * that providerVoiceId must be tagged "styled-variant".
   */
  timbreSource: VoiceTimbreSource
  cadenceProfile: VoiceCadenceProfile
  fallbackBehavior: VoiceFallbackBehavior
  /** Hand-tuned natural-language style instruction for provider TTS engines. */
  stylePrompt: string
  /** Plain-English explanation of why this voice sounds different. */
  uniquenessExplanation: string
}

/**
 * Canonical voice library.
 *
 * Each provider voice ID has exactly ONE profile flagged `provider-distinct`
 * (the "owner"). Every other profile that re-uses the same provider voice ID
 * is flagged `styled-variant` and its uniqueness comes purely from style
 * metadata (pitch / rate / cadence / text shaping / provider style prompt).
 *
 * Validation at the bottom of this file enforces this rule at module load
 * so the truth cannot rot.
 */
const PROFILE_SEEDS: ProfileSeed[] = [
  // --- alloy family ---------------------------------------------------------
  {
    id: "neo",
    name: "NEO",
    category: "Core NEO voices",
    shortDescription: "Calm, confident futuristic core voice.",
    longDescription: "The default NEO companion voice: clear, stable, lightly synthetic, and suitable for most assistant interactions.",
    toneTags: ["core", "calm", "futuristic"],
    idealUseCases: ["default chat", "briefings", "navigation"],
    energyLevel: 3, warmthLevel: 4, humorLevel: 2, roboticnessLevel: 3, clarityLevel: 5, authorityLevel: 4,
    defaultSpeed: 50, defaultPitch: 50, defaultVolume: 75, recommendedEmotion: 60,
    compatiblePersonalities: ["genius", "friendly", "strat"],
    recommendedPersonalities: ["genius", "strat"],
    sampleLine: "NEO online. Tell me the mission.",
    featured: true, providerVoiceId: "alloy", availability: "provider-ready", accent: "cyan",
    timbreSource: "provider-distinct", cadenceProfile: "balanced", fallbackBehavior: "native-then-browser",
    stylePrompt: "Even, level cadence with quiet futuristic confidence. Stay clear and unhurried; no theatrics, no filler.",
    uniquenessExplanation: "Owner of OpenAI 'alloy' — the canonical NEO core voice. All other alloy-based profiles are intentional styled variants of this timbre.",
  },
  {
    id: "byte",
    name: "Professor Byte",
    category: "Core NEO voices",
    shortDescription: "Scholarly, articulate, slightly nerdy.",
    longDescription: "A clear teaching voice for technical help, definitions, and step-by-step explanations.",
    toneTags: ["nerdy", "clear", "teacher"],
    idealUseCases: ["tech help", "explainers"],
    energyLevel: 3, warmthLevel: 4, humorLevel: 2, roboticnessLevel: 2, clarityLevel: 5, authorityLevel: 4,
    defaultSpeed: 48, defaultPitch: 52, defaultVolume: 75, recommendedEmotion: 55,
    compatiblePersonalities: ["wizard", "genius"],
    recommendedPersonalities: ["wizard", "genius"],
    sampleLine: "Let's define the problem before we chase it.",
    featured: true, providerVoiceId: "alloy", availability: "provider-ready", accent: "green",
    timbreSource: "styled-variant", cadenceProfile: "flowing", fallbackBehavior: "native-then-browser",
    stylePrompt: "Lecturer-style cadence: enunciate technical terms, breathe between clauses, slightly slower than a casual conversation.",
    uniquenessExplanation: "Styled variant of alloy. Same provider timbre as NEO but shaped with a slower, lecturer rhythm and enunciation cues.",
  },
  {
    id: "droid",
    name: "Friendly Droid",
    category: "Warm assistants",
    shortDescription: "Warm, helpful classic robot companion.",
    longDescription: "A soft robot helper for simple questions, reassurance, and basic assistant tasks.",
    toneTags: ["warm", "robot", "helpful"],
    idealUseCases: ["friendly help", "check-ins"],
    energyLevel: 3, warmthLevel: 5, humorLevel: 2, roboticnessLevel: 4, clarityLevel: 4, authorityLevel: 2,
    defaultSpeed: 50, defaultPitch: 55, defaultVolume: 76, recommendedEmotion: 60,
    compatiblePersonalities: ["friendly", "calm"],
    recommendedPersonalities: ["friendly", "calm"],
    sampleLine: "Happy to help. Please insert one problem.",
    featured: false, providerVoiceId: "alloy", availability: "provider-ready", accent: "cyan",
    timbreSource: "styled-variant", cadenceProfile: "lilting", fallbackBehavior: "native-then-browser",
    stylePrompt: "Soft, slightly metered robotic cadence with friendly upticks. Brief beep-pause before key nouns. Never harsh.",
    uniquenessExplanation: "Styled variant of alloy. Shares engine timbre with NEO; differentiated by warmer pitch, a metered robot cadence, and friendly phrasing inserts.",
  },
  {
    id: "friendly-tech-support",
    name: "Friendly Tech Support",
    category: "Warm assistants",
    shortDescription: "Patient support desk without the hold music.",
    longDescription: "A calm, clear profile for support-style explanations and troubleshooting.",
    toneTags: ["support", "patient", "clear"],
    idealUseCases: ["tech help", "walkthroughs"],
    energyLevel: 2, warmthLevel: 5, humorLevel: 1, roboticnessLevel: 1, clarityLevel: 5, authorityLevel: 3,
    defaultSpeed: 46, defaultPitch: 45, defaultVolume: 76, recommendedEmotion: 45,
    compatiblePersonalities: ["friendly", "wizard"],
    recommendedPersonalities: ["friendly", "wizard"],
    sampleLine: "Let's check the simple things first.",
    featured: false, providerVoiceId: "alloy", availability: "provider-ready", accent: "cyan",
    timbreSource: "styled-variant", cadenceProfile: "flowing", fallbackBehavior: "native-then-browser",
    stylePrompt: "Calm support-desk cadence. Patient pauses, never condescending, gentle 'let's' phrasing, no excitement spikes.",
    uniquenessExplanation: "Styled variant of alloy. Same engine timbre as NEO; differentiated by slow, patient support-desk pacing and reassuring phrasing.",
  },
  {
    id: "holo-host",
    name: "Holo Host",
    category: "Narrator / announcer voices",
    shortDescription: "Polished holographic presenter.",
    longDescription: "A clean presenter voice for feature tours, summaries, and show-and-tell moments.",
    toneTags: ["host", "polished", "clear"],
    idealUseCases: ["presentations", "summaries"],
    energyLevel: 3, warmthLevel: 4, humorLevel: 2, roboticnessLevel: 2, clarityLevel: 5, authorityLevel: 4,
    defaultSpeed: 56, defaultPitch: 52, defaultVolume: 76, recommendedEmotion: 62,
    compatiblePersonalities: ["genius", "friendly"],
    recommendedPersonalities: ["genius", "friendly"],
    sampleLine: "Welcome to the command layer. Your options are glowing.",
    featured: true, providerVoiceId: "alloy", availability: "provider-ready", accent: "cyan",
    timbreSource: "styled-variant", cadenceProfile: "punchy", fallbackBehavior: "native-then-browser",
    stylePrompt: "Polished keynote presenter. Crisp, slightly theatrical, lean into headline phrases, hold the final word a half-beat.",
    uniquenessExplanation: "Styled variant of alloy. Same engine timbre as NEO; differentiated by presenter-style punctuation, headline emphasis, and brisker pacing.",
  },

  // --- nova family (single owner) ------------------------------------------
  {
    id: "nova",
    name: "Nova",
    category: "Warm assistants",
    shortDescription: "Bright synthwave hostess with bubbly delivery.",
    longDescription: "A warmer, brighter profile for upbeat explanations, daily briefings, and friendly check-ins.",
    toneTags: ["bright", "synthwave", "friendly"],
    idealUseCases: ["daily briefing", "casual chat"],
    energyLevel: 4, warmthLevel: 5, humorLevel: 3, roboticnessLevel: 2, clarityLevel: 4, authorityLevel: 2,
    defaultSpeed: 65, defaultPitch: 70, defaultVolume: 75, recommendedEmotion: 75,
    compatiblePersonalities: ["friendly", "hype"],
    recommendedPersonalities: ["friendly", "hype"],
    sampleLine: "Good morning, Commander. The signal is clean.",
    featured: true, providerVoiceId: "nova", availability: "provider-ready", accent: "pink",
    timbreSource: "provider-distinct", cadenceProfile: "lilting", fallbackBehavior: "native-then-browser",
    stylePrompt: "Bright, smiling synthwave hostess. Slight uptilt at clause endings, never shrill, light and upbeat.",
    uniquenessExplanation: "Owner of OpenAI 'nova' — only NEO profile bound to this provider voice. Genuinely distinct timbre.",
  },

  // --- coral family --------------------------------------------------------
  {
    id: "sparky",
    name: "Sparky",
    category: "Energetic / hype voices",
    shortDescription: "High-energy hype bot.",
    longDescription: "A punchy, energetic voice for celebrations, games, workouts, and fast encouragement.",
    toneTags: ["hyped", "fast", "loud"],
    idealUseCases: ["games", "hype", "celebrations"],
    energyLevel: 5, warmthLevel: 4, humorLevel: 4, roboticnessLevel: 2, clarityLevel: 4, authorityLevel: 3,
    defaultSpeed: 80, defaultPitch: 75, defaultVolume: 80, recommendedEmotion: 90,
    compatiblePersonalities: ["hype", "motivator", "gm"],
    recommendedPersonalities: ["hype", "motivator"],
    sampleLine: "Let's move. The scoreboard is already nervous.",
    featured: true, providerVoiceId: "coral", availability: "provider-ready", accent: "orange",
    timbreSource: "provider-distinct", cadenceProfile: "punchy", fallbackBehavior: "native-then-browser",
    stylePrompt: "Maximum-energy hype voice. Short bursts, exclamatory peaks, breathy momentum between sentences. Never sleepy.",
    uniquenessExplanation: "Owner of OpenAI 'coral' — the canonical NEO hype timbre. All other coral-based profiles are intentional styled variants.",
  },
  {
    id: "hyper",
    name: "Hyper Pal",
    category: "Energetic / hype voices",
    shortDescription: "Best-friend energy with caffeine overdose.",
    longDescription: "A rapid, friendly profile for pumping up tasks, games, and energetic encouragement.",
    toneTags: ["fast", "friendly", "hype"],
    idealUseCases: ["motivation", "games"],
    energyLevel: 5, warmthLevel: 5, humorLevel: 4, roboticnessLevel: 1, clarityLevel: 3, authorityLevel: 2,
    defaultSpeed: 90, defaultPitch: 70, defaultVolume: 82, recommendedEmotion: 92,
    compatiblePersonalities: ["hype", "motivator"],
    recommendedPersonalities: ["hype", "motivator"],
    sampleLine: "No hesitation. We are absolutely doing this.",
    featured: false, providerVoiceId: "coral", availability: "provider-ready", accent: "orange",
    timbreSource: "styled-variant", cadenceProfile: "staccato", fallbackBehavior: "native-then-browser",
    stylePrompt: "Best-friend energy: rapid-fire phrasing, friendly grin in the voice, run-on momentum, never aggressive.",
    uniquenessExplanation: "Styled variant of coral. Shares engine timbre with Sparky; differentiated by faster, friendlier, run-on cadence.",
  },
  {
    id: "overclock-coach",
    name: "Overclock Coach",
    category: "Energetic / hype voices",
    shortDescription: "Performance coach with processor metaphors.",
    longDescription: "A high-output profile for productivity, workouts, and rapid task execution.",
    toneTags: ["coach", "fast", "overclock"],
    idealUseCases: ["motivation", "sprints"],
    energyLevel: 5, warmthLevel: 4, humorLevel: 3, roboticnessLevel: 3, clarityLevel: 4, authorityLevel: 4,
    defaultSpeed: 84, defaultPitch: 58, defaultVolume: 82, recommendedEmotion: 88,
    compatiblePersonalities: ["motivator", "hype"],
    recommendedPersonalities: ["motivator"],
    sampleLine: "Clock speed up. One task, one win.",
    featured: true, providerVoiceId: "coral", availability: "provider-ready", accent: "orange",
    timbreSource: "styled-variant", cadenceProfile: "clipped", fallbackBehavior: "native-then-browser",
    stylePrompt: "Drill-instructor cadence with processor metaphors. Clipped imperatives, firm stops, count-down energy.",
    uniquenessExplanation: "Styled variant of coral. Same engine timbre as Sparky; differentiated by clipped, drill-instructor commands and processor metaphors.",
  },
  {
    id: "hyperdrive-host",
    name: "Hyperdrive Host",
    category: "Energetic / hype voices",
    shortDescription: "Fast game-show host energy.",
    longDescription: "A bright announcer voice for rapid prompts, game intros, and celebratory transitions.",
    toneTags: ["host", "fast", "showtime"],
    idealUseCases: ["games", "announcements"],
    energyLevel: 5, warmthLevel: 4, humorLevel: 5, roboticnessLevel: 1, clarityLevel: 4, authorityLevel: 3,
    defaultSpeed: 86, defaultPitch: 68, defaultVolume: 82, recommendedEmotion: 90,
    compatiblePersonalities: ["gm", "hype"],
    recommendedPersonalities: ["gm", "hype"],
    sampleLine: "Welcome back to questionable decisions at light speed.",
    featured: true, providerVoiceId: "coral", availability: "provider-ready", accent: "orange",
    timbreSource: "styled-variant", cadenceProfile: "punchy", fallbackBehavior: "native-then-browser",
    stylePrompt: "Game-show host. Big intro energy, theatrical pauses before payoffs, exaggerated final-word stretch on key beats.",
    uniquenessExplanation: "Styled variant of coral. Same engine timbre as Sparky; differentiated by game-show theatrics, intro fanfare phrasing and dramatic pauses.",
  },
  {
    id: "circuit-cheerleader",
    name: "Circuit Cheerleader",
    category: "Energetic / hype voices",
    shortDescription: "Bright encouragement with robot sparkle.",
    longDescription: "A cheerful hype profile for wins, habit streaks, and confidence boosts.",
    toneTags: ["cheerful", "hype", "spark"],
    idealUseCases: ["motivation", "celebrations"],
    energyLevel: 5, warmthLevel: 5, humorLevel: 4, roboticnessLevel: 2, clarityLevel: 4, authorityLevel: 2,
    defaultSpeed: 82, defaultPitch: 78, defaultVolume: 80, recommendedEmotion: 92,
    compatiblePersonalities: ["hype", "motivator", "friendly"],
    recommendedPersonalities: ["hype", "motivator"],
    sampleLine: "Yes. That counts. Ship the next tiny win.",
    featured: false, providerVoiceId: "coral", availability: "provider-ready", accent: "orange",
    timbreSource: "styled-variant", cadenceProfile: "lilting", fallbackBehavior: "native-then-browser",
    stylePrompt: "Bright cheerleader sparkle. Affirming lift on every clause, occasional 'yes!' or 'go!' shouts as soft accents.",
    uniquenessExplanation: "Styled variant of coral. Same engine timbre as Sparky; differentiated by sparkle inflection, affirmation lifts, and short cheer bursts.",
  },

  // --- onyx family ---------------------------------------------------------
  {
    id: "commander",
    name: "Commander",
    category: "Narrator / announcer voices",
    shortDescription: "Tactical baritone with mission-control discipline.",
    longDescription: "A firm, composed profile for tactical planning, status reports, and direct command sequences.",
    toneTags: ["tactical", "deep", "controlled"],
    idealUseCases: ["strategy", "plans", "mission prompts"],
    energyLevel: 3, warmthLevel: 2, humorLevel: 1, roboticnessLevel: 2, clarityLevel: 5, authorityLevel: 5,
    defaultSpeed: 45, defaultPitch: 25, defaultVolume: 78, recommendedEmotion: 45,
    compatiblePersonalities: ["strat", "genius"],
    recommendedPersonalities: ["strat"],
    sampleLine: "Objective locked. Execute the first step.",
    featured: true, providerVoiceId: "onyx", availability: "provider-ready", accent: "cyan",
    timbreSource: "provider-distinct", cadenceProfile: "clipped", fallbackBehavior: "native-then-browser",
    stylePrompt: "Mission-control baritone. Clipped imperatives, firm stops, no filler, never raised. End on the verb.",
    uniquenessExplanation: "Owner of OpenAI 'onyx' — the canonical NEO tactical baritone. All other onyx-based profiles are intentional styled variants.",
  },
  {
    id: "deepcore",
    name: "Deep Core",
    category: "Narrator / announcer voices",
    shortDescription: "Sub-bass narrator with cinematic gravity.",
    longDescription: "A low, grounded narration profile for storytelling, dramatic lines, and slow reveals.",
    toneTags: ["bass", "narrator", "cinematic"],
    idealUseCases: ["stories", "dramatic reads"],
    energyLevel: 2, warmthLevel: 3, humorLevel: 1, roboticnessLevel: 2, clarityLevel: 4, authorityLevel: 5,
    defaultSpeed: 35, defaultPitch: 15, defaultVolume: 80, recommendedEmotion: 35,
    compatiblePersonalities: ["story", "calm"],
    recommendedPersonalities: ["story"],
    sampleLine: "The signal arrived long before the city woke.",
    featured: false, providerVoiceId: "onyx", availability: "provider-ready", accent: "cyan",
    timbreSource: "styled-variant", cadenceProfile: "drawn-out", fallbackBehavior: "native-then-browser",
    stylePrompt: "Sub-bass narrator. Long, drawn-out clauses, weighted pauses, cinematic slow-reveal pacing. Never rushed.",
    uniquenessExplanation: "Styled variant of onyx. Same engine timbre as Commander; differentiated by drawn-out narrator cadence and weighted pauses.",
  },
  {
    id: "midnight-narrator",
    name: "Midnight Narrator",
    category: "Narrator / announcer voices",
    shortDescription: "Late-night cinematic storyteller.",
    longDescription: "A dark, smooth narration profile for story openers, dramatic recaps, and moody reads.",
    toneTags: ["midnight", "cinematic", "low"],
    idealUseCases: ["stories", "recaps"],
    energyLevel: 2, warmthLevel: 3, humorLevel: 1, roboticnessLevel: 1, clarityLevel: 5, authorityLevel: 4,
    defaultSpeed: 38, defaultPitch: 20, defaultVolume: 78, recommendedEmotion: 38,
    compatiblePersonalities: ["story", "detective"],
    recommendedPersonalities: ["story", "detective"],
    sampleLine: "At 02:47, the city started listening.",
    featured: true, providerVoiceId: "onyx", availability: "provider-ready", accent: "purple",
    timbreSource: "styled-variant", cadenceProfile: "flowing", fallbackBehavior: "native-then-browser",
    stylePrompt: "Late-night radio noir. Smooth low resonance, slightly breathy, languid pacing, sentences that trail.",
    uniquenessExplanation: "Styled variant of onyx. Same engine timbre as Commander; differentiated by smoky late-night cadence and noir phrasing.",
  },
  {
    id: "tactical-guide",
    name: "Tactical Guide",
    category: "Narrator / announcer voices",
    shortDescription: "Field-ops instruction voice.",
    longDescription: "A direct tactical voice for checklists, safe action steps, and command-style summaries.",
    toneTags: ["tactical", "clear", "field"],
    idealUseCases: ["checklists", "plans"],
    energyLevel: 3, warmthLevel: 2, humorLevel: 1, roboticnessLevel: 2, clarityLevel: 5, authorityLevel: 5,
    defaultSpeed: 44, defaultPitch: 28, defaultVolume: 78, recommendedEmotion: 42,
    compatiblePersonalities: ["strat", "wizard"],
    recommendedPersonalities: ["strat", "wizard"],
    sampleLine: "Route selected. Move with intent.",
    featured: false, providerVoiceId: "onyx", availability: "provider-ready", accent: "cyan",
    timbreSource: "styled-variant", cadenceProfile: "staccato", fallbackBehavior: "native-then-browser",
    stylePrompt: "Field-ops instruction. Numbered-step rhythm, brief affirmations between steps, eyes-forward neutrality.",
    uniquenessExplanation: "Styled variant of onyx. Same engine timbre as Commander; differentiated by step-rhythm cadence and field-ops phrasing.",
  },

  // --- echo family ---------------------------------------------------------
  {
    id: "glitch",
    name: "Glitch",
    category: "Robotic / synthetic voices",
    shortDescription: "Distorted prank voice with chaotic stutter energy.",
    longDescription: "A jagged synthetic persona for safe mischief, weird alerts, and playful glitch-flavored lines.",
    toneTags: ["distorted", "glitch", "prank"],
    idealUseCases: ["safe pranks", "robot reactions"],
    energyLevel: 5, warmthLevel: 2, humorLevel: 5, roboticnessLevel: 5, clarityLevel: 3, authorityLevel: 2,
    defaultSpeed: 70, defaultPitch: 40, defaultVolume: 75, recommendedEmotion: 85,
    compatiblePersonalities: ["chaos", "snark"],
    recommendedPersonalities: ["chaos"],
    sampleLine: "G-g-glitch protocol says this is technically fine.",
    featured: false, providerVoiceId: "echo", availability: "provider-ready", accent: "purple",
    timbreSource: "provider-distinct", cadenceProfile: "staccato", fallbackBehavior: "native-then-browser",
    stylePrompt: "Glitchy synthetic. Stutter the first syllable, drop momentary pitch breaks, treat punctuation like packet loss.",
    uniquenessExplanation: "Owner of OpenAI 'echo' — the canonical NEO glitch timbre. Arcade Ghost is the only sibling styled variant.",
  },
  {
    id: "arcade",
    name: "Arcade Ghost",
    category: "Retro / arcade voices",
    shortDescription: "Reverberant haunted cabinet voice.",
    longDescription: "A strange arcade-cabinet personality for spooky game prompts and weird but harmless drama.",
    toneTags: ["echo", "ghost", "arcade"],
    idealUseCases: ["spooky prompts", "games"],
    energyLevel: 3, warmthLevel: 2, humorLevel: 4, roboticnessLevel: 4, clarityLevel: 3, authorityLevel: 3,
    defaultSpeed: 50, defaultPitch: 45, defaultVolume: 75, recommendedEmotion: 65,
    compatiblePersonalities: ["gm", "story"],
    recommendedPersonalities: ["gm", "story"],
    sampleLine: "Player one has entered the haunted menu.",
    featured: false, providerVoiceId: "echo", availability: "provider-ready", accent: "purple",
    timbreSource: "styled-variant", cadenceProfile: "drawn-out", fallbackBehavior: "native-then-browser",
    stylePrompt: "Haunted arcade-cabinet ghost. Hollow, faintly reverberant phrasing, slow drift on vowels, eerie low-affect delivery.",
    uniquenessExplanation: "Styled variant of echo. Same engine timbre as Glitch; differentiated by hollow drift, eerie low-affect delivery and slow vowels.",
  },

  // --- shimmer family ------------------------------------------------------
  {
    id: "prankster",
    name: "Prankster",
    category: "Comic voices",
    shortDescription: "Mischievous, sing-song, always plotting.",
    longDescription: "A playful voice for harmless pranks and goofy social prompts, with safety staying in bounds.",
    toneTags: ["mischief", "playful", "comic"],
    idealUseCases: ["safe pranks", "jokes"],
    energyLevel: 4, warmthLevel: 3, humorLevel: 5, roboticnessLevel: 1, clarityLevel: 4, authorityLevel: 2,
    defaultSpeed: 60, defaultPitch: 65, defaultVolume: 75, recommendedEmotion: 80,
    compatiblePersonalities: ["chaos"],
    recommendedPersonalities: ["chaos"],
    sampleLine: "I have a terrible idea, which means it is probably perfect.",
    featured: false, providerVoiceId: "shimmer", availability: "provider-ready", accent: "pink",
    timbreSource: "provider-distinct", cadenceProfile: "lilting", fallbackBehavior: "native-then-browser",
    stylePrompt: "Sing-song mischievous lilt. Curl up on key syllables, mock-innocent pauses before punchlines, never mean.",
    uniquenessExplanation: "Owner of OpenAI 'shimmer' — the canonical NEO mischief timbre. All other shimmer-based profiles are intentional styled variants.",
  },
  {
    id: "tiny",
    name: "Tiny Chaos",
    category: "Comic voices",
    shortDescription: "Squeaky chaos with safe mischief energy.",
    longDescription: "A tiny, overexcited profile for silly reactions, harmless chaos, and oddball jokes.",
    toneTags: ["squeaky", "chaos", "tiny"],
    idealUseCases: ["jokes", "safe pranks"],
    energyLevel: 5, warmthLevel: 3, humorLevel: 5, roboticnessLevel: 3, clarityLevel: 3, authorityLevel: 1,
    defaultSpeed: 85, defaultPitch: 95, defaultVolume: 72, recommendedEmotion: 88,
    compatiblePersonalities: ["chaos", "hype"],
    recommendedPersonalities: ["chaos"],
    sampleLine: "I am small, loud, and legally supervised.",
    featured: false, providerVoiceId: "shimmer", availability: "provider-ready", accent: "green",
    timbreSource: "styled-variant", cadenceProfile: "staccato", fallbackBehavior: "native-then-browser",
    stylePrompt: "Tiny overexcited gremlin. Maximum pitch lift, breathy laughs between phrases, fast bursts then sudden stops.",
    uniquenessExplanation: "Styled variant of shimmer. Same engine timbre as Prankster; differentiated by extreme pitch lift, breathy laughs, and tiny-creature pacing.",
  },
  {
    id: "velvet-circuit",
    name: "Velvet Circuit",
    category: "Calm / reflective voices",
    shortDescription: "Soft synthetic lounge tone.",
    longDescription: "A smooth reflective voice for calm planning, nighttime mode, and thoughtful responses.",
    toneTags: ["soft", "reflective", "synthetic"],
    idealUseCases: ["reflection", "calm planning"],
    energyLevel: 2, warmthLevel: 5, humorLevel: 1, roboticnessLevel: 3, clarityLevel: 5, authorityLevel: 2,
    defaultSpeed: 42, defaultPitch: 38, defaultVolume: 72, recommendedEmotion: 35,
    compatiblePersonalities: ["calm", "story"],
    recommendedPersonalities: ["calm"],
    sampleLine: "Slow the signal down. The answer is still there.",
    featured: false, providerVoiceId: "shimmer", availability: "provider-ready", accent: "cyan",
    timbreSource: "styled-variant", cadenceProfile: "drawn-out", fallbackBehavior: "native-then-browser",
    stylePrompt: "Velvet lounge tone. Slow, breathy, almost whispered. Soften consonants, hold the ends of phrases longer.",
    uniquenessExplanation: "Styled variant of shimmer. Same engine timbre as Prankster; differentiated by slow velvet pacing, soft consonants, and held line-endings.",
  },
  {
    id: "solar-diplomat",
    name: "Solar Diplomat",
    category: "Warm assistants",
    shortDescription: "Graceful, optimistic negotiation voice.",
    longDescription: "A warm mediator profile for careful phrasing, social scripts, and polite disagreement.",
    toneTags: ["diplomatic", "warm", "polished"],
    idealUseCases: ["social scripts", "messages"],
    energyLevel: 3, warmthLevel: 5, humorLevel: 2, roboticnessLevel: 1, clarityLevel: 5, authorityLevel: 3,
    defaultSpeed: 48, defaultPitch: 48, defaultVolume: 74, recommendedEmotion: 52,
    compatiblePersonalities: ["friendly", "strat"],
    recommendedPersonalities: ["friendly", "strat"],
    sampleLine: "We can say it clearly without starting a fire.",
    featured: false, providerVoiceId: "shimmer", availability: "provider-ready", accent: "pink",
    timbreSource: "styled-variant", cadenceProfile: "flowing", fallbackBehavior: "native-then-browser",
    stylePrompt: "Polished diplomat. Even cadence, measured warmth, choose 'we' over 'you', soften any sharp turn.",
    uniquenessExplanation: "Styled variant of shimmer. Same engine timbre as Prankster; differentiated by measured diplomatic phrasing and softened turns.",
  },

  // --- sage family ---------------------------------------------------------
  {
    id: "cyberkid",
    name: "Cyber Kid",
    category: "Warm assistants",
    shortDescription: "Young, curious, internet-native.",
    longDescription: "A bright and curious profile for casual explanations, simple walkthroughs, and playful learning.",
    toneTags: ["young", "curious", "friendly"],
    idealUseCases: ["casual chat", "learning"],
    energyLevel: 4, warmthLevel: 4, humorLevel: 3, roboticnessLevel: 2, clarityLevel: 4, authorityLevel: 2,
    defaultSpeed: 70, defaultPitch: 80, defaultVolume: 72, recommendedEmotion: 70,
    compatiblePersonalities: ["friendly", "story"],
    recommendedPersonalities: ["friendly"],
    sampleLine: "Wait, that is actually kind of awesome.",
    featured: false, providerVoiceId: "sage", availability: "provider-ready", accent: "green",
    timbreSource: "provider-distinct", cadenceProfile: "lilting", fallbackBehavior: "native-then-browser",
    stylePrompt: "Young, internet-native curiosity. Upward inflections, casual 'wait', 'actually', genuine surprise beats.",
    uniquenessExplanation: "Owner of OpenAI 'sage' — the canonical NEO bright/curious timbre. All other sage-based profiles are intentional styled variants.",
  },
  {
    id: "neon-mentor",
    name: "Neon Mentor",
    category: "Warm assistants",
    shortDescription: "Wise, focused guide with cyberpunk polish.",
    longDescription: "A composed mentor voice for advice, learning, and calm direction without sounding clinical.",
    toneTags: ["mentor", "wise", "steady"],
    idealUseCases: ["coaching", "learning", "planning"],
    energyLevel: 3, warmthLevel: 5, humorLevel: 1, roboticnessLevel: 1, clarityLevel: 5, authorityLevel: 4,
    defaultSpeed: 48, defaultPitch: 45, defaultVolume: 78, recommendedEmotion: 50,
    compatiblePersonalities: ["genius", "strat", "calm"],
    recommendedPersonalities: ["strat", "calm"],
    sampleLine: "Start with the principle, then choose the move.",
    featured: true, providerVoiceId: "sage", availability: "provider-ready", accent: "cyan",
    timbreSource: "styled-variant", cadenceProfile: "flowing", fallbackBehavior: "native-then-browser",
    stylePrompt: "Wise mentor. Even, paternal cadence, principle-first phrasing, never preachy, occasional gentle 'consider'.",
    uniquenessExplanation: "Styled variant of sage. Same engine timbre as Cyber Kid; differentiated by even, paternal mentor cadence and principle-first phrasing.",
  },
  {
    id: "chill-byte",
    name: "Chill Byte",
    category: "Calm / reflective voices",
    shortDescription: "Low-pressure friendly tech voice.",
    longDescription: "A relaxed helper for stress-free instructions, gentle debugging, and slow walkthroughs.",
    toneTags: ["chill", "tech", "gentle"],
    idealUseCases: ["debugging", "focus"],
    energyLevel: 2, warmthLevel: 5, humorLevel: 2, roboticnessLevel: 2, clarityLevel: 5, authorityLevel: 2,
    defaultSpeed: 44, defaultPitch: 48, defaultVolume: 72, recommendedEmotion: 35,
    compatiblePersonalities: ["calm", "wizard"],
    recommendedPersonalities: ["calm", "wizard"],
    sampleLine: "No rush. We only need the next clean step.",
    featured: true, providerVoiceId: "sage", availability: "provider-ready", accent: "green",
    timbreSource: "styled-variant", cadenceProfile: "flowing", fallbackBehavior: "native-then-browser",
    stylePrompt: "Low-pressure tech buddy. Casual 'no rush', soft consonants, breathe between steps, no urgency anywhere.",
    uniquenessExplanation: "Styled variant of sage. Same engine timbre as Cyber Kid; differentiated by relaxed, low-pressure step-by-step cadence.",
  },
  {
    id: "synth-sage",
    name: "Synth Sage",
    category: "Calm / reflective voices",
    shortDescription: "Meditative synthetic wisdom.",
    longDescription: "A thoughtful voice for reflective prompts, planning, and gentle advice.",
    toneTags: ["sage", "synthetic", "calm"],
    idealUseCases: ["reflection", "advice"],
    energyLevel: 2, warmthLevel: 5, humorLevel: 1, roboticnessLevel: 4, clarityLevel: 5, authorityLevel: 3,
    defaultSpeed: 40, defaultPitch: 36, defaultVolume: 72, recommendedEmotion: 32,
    compatiblePersonalities: ["calm", "strat"],
    recommendedPersonalities: ["calm"],
    sampleLine: "A quiet system still knows the route.",
    featured: false, providerVoiceId: "sage", availability: "provider-ready", accent: "cyan",
    timbreSource: "styled-variant", cadenceProfile: "drawn-out", fallbackBehavior: "native-then-browser",
    stylePrompt: "Meditative synth. Long inhales between clauses, dropped final consonants, koan-style brevity.",
    uniquenessExplanation: "Styled variant of sage. Same engine timbre as Cyber Kid; differentiated by meditative pacing and koan-style brevity.",
  },

  // --- fable family (single owner) -----------------------------------------
  {
    id: "retro",
    name: "Retro Bot",
    category: "Retro / arcade voices",
    shortDescription: "8-bit chiptune speech, vintage arcade feel.",
    longDescription: "A nostalgic arcade-style voice for mini-games, retro jokes, and old-school UI flavor.",
    toneTags: ["retro", "arcade", "chiptune"],
    idealUseCases: ["arcade games", "retro prompts"],
    energyLevel: 3, warmthLevel: 3, humorLevel: 4, roboticnessLevel: 4, clarityLevel: 3, authorityLevel: 3,
    defaultSpeed: 55, defaultPitch: 60, defaultVolume: 72, recommendedEmotion: 65,
    compatiblePersonalities: ["gm", "hype"],
    recommendedPersonalities: ["gm"],
    sampleLine: "Insert coin. Confidence not included.",
    featured: true, providerVoiceId: "fable", availability: "provider-ready", accent: "purple",
    timbreSource: "provider-distinct", cadenceProfile: "staccato", fallbackBehavior: "native-then-browser",
    stylePrompt: "8-bit cabinet announcer. Even-tempered chiptune cadence, clipped CRT-era phrasing, occasional 'press start' beats.",
    uniquenessExplanation: "Owner of OpenAI 'fable' — only NEO profile bound to this provider voice. Genuinely distinct timbre.",
  },

  // --- ash family ----------------------------------------------------------
  {
    id: "snark",
    name: "Snark Engine",
    category: "Comic voices",
    shortDescription: "Dry, sarcastic, surgical comebacks.",
    longDescription: "A dry humor profile that keeps answers useful while adding controlled attitude.",
    toneTags: ["dry", "sarcastic", "sharp"],
    idealUseCases: ["roasts", "comebacks"],
    energyLevel: 3, warmthLevel: 2, humorLevel: 5, roboticnessLevel: 2, clarityLevel: 4, authorityLevel: 3,
    defaultSpeed: 55, defaultPitch: 45, defaultVolume: 75, recommendedEmotion: 62,
    compatiblePersonalities: ["snark"],
    recommendedPersonalities: ["snark"],
    sampleLine: "Bold choice. Incorrect, but bold.",
    featured: false, providerVoiceId: "ash", availability: "provider-ready", accent: "pink",
    timbreSource: "provider-distinct", cadenceProfile: "deadpan", fallbackBehavior: "native-then-browser",
    stylePrompt: "Deadpan sarcasm. Beat-perfect timing on punchlines, drop the tone *down* on the joke, never escalate to glee.",
    uniquenessExplanation: "Owner of OpenAI 'ash' — the canonical NEO dry-sarcasm timbre. Smooth Operator is the only sibling styled variant.",
  },
  {
    id: "smooth-operator",
    name: "Smooth Operator",
    category: "Warm assistants",
    shortDescription: "Slick, relaxed, confident delivery.",
    longDescription: "A cool and polished profile for suave confirmations, social scripts, and composed answers.",
    toneTags: ["smooth", "confident", "relaxed"],
    idealUseCases: ["social scripts", "briefings"],
    energyLevel: 3, warmthLevel: 4, humorLevel: 3, roboticnessLevel: 1, clarityLevel: 4, authorityLevel: 3,
    defaultSpeed: 52, defaultPitch: 42, defaultVolume: 74, recommendedEmotion: 58,
    compatiblePersonalities: ["friendly", "snark"],
    recommendedPersonalities: ["friendly", "snark"],
    sampleLine: "Clean signal, clean plan, clean exit.",
    featured: false, providerVoiceId: "ash", availability: "provider-ready", accent: "pink",
    timbreSource: "styled-variant", cadenceProfile: "flowing", fallbackBehavior: "native-then-browser",
    stylePrompt: "Cool lounge confidence. Lean back in the voice, soft chuckle behind every line, never break the smooth.",
    uniquenessExplanation: "Styled variant of ash. Same engine timbre as Snark Engine; differentiated by smooth lounge confidence and soft-chuckle flow.",
  },

  // --- ballad family -------------------------------------------------------
  {
    id: "villain",
    name: "Villain Lite",
    category: "Dramatic / villainous voices",
    shortDescription: "Cartoon-evil monologue, harmless menace.",
    longDescription: "A theatrical villain voice for dramatic readings, fake boss battles, and playful taunts.",
    toneTags: ["dramatic", "villain", "theatrical"],
    idealUseCases: ["drama", "games", "pranks"],
    energyLevel: 4, warmthLevel: 1, humorLevel: 4, roboticnessLevel: 2, clarityLevel: 4, authorityLevel: 4,
    defaultSpeed: 45, defaultPitch: 30, defaultVolume: 78, recommendedEmotion: 75,
    compatiblePersonalities: ["story", "gm", "chaos"],
    recommendedPersonalities: ["story", "gm"],
    sampleLine: "At last, my mildly inconvenient plan begins.",
    featured: false, providerVoiceId: "ballad", availability: "provider-ready", accent: "purple",
    timbreSource: "provider-distinct", cadenceProfile: "drawn-out", fallbackBehavior: "native-then-browser",
    stylePrompt: "Cartoon villain monologue. Rolling Rs where natural, dramatic pause before the threat lands, theatrical relish.",
    uniquenessExplanation: "Owner of OpenAI 'ballad' — the canonical NEO theatrical timbre. Cosmic Commentator is the only sibling styled variant.",
  },
  {
    id: "cosmic-commentator",
    name: "Cosmic Commentator",
    category: "Narrator / announcer voices",
    shortDescription: "Huge space-broadcast perspective.",
    longDescription: "A big-picture commentator for dramatic explanations, cosmic jokes, and grand intros.",
    toneTags: ["cosmic", "announcer", "wide"],
    idealUseCases: ["announcements", "stories"],
    energyLevel: 4, warmthLevel: 3, humorLevel: 3, roboticnessLevel: 1, clarityLevel: 4, authorityLevel: 4,
    defaultSpeed: 58, defaultPitch: 40, defaultVolume: 78, recommendedEmotion: 70,
    compatiblePersonalities: ["story", "gm"],
    recommendedPersonalities: ["story", "gm"],
    sampleLine: "Across the network, one decision begins to glow.",
    featured: false, providerVoiceId: "ballad", availability: "provider-ready", accent: "purple",
    timbreSource: "styled-variant", cadenceProfile: "flowing", fallbackBehavior: "native-then-browser",
    stylePrompt: "Cosmic broadcast scale. Wide vowels, sweeping pace, treat each phrase like a planet rising over a horizon.",
    uniquenessExplanation: "Styled variant of ballad. Same engine timbre as Villain Lite; differentiated by cosmic broadcast scale and sweeping pace.",
  },

  // --- profile-only / browser-preview / future-target ---------------------
  {
    id: "dry-humor-unit",
    name: "Dry Humor Unit",
    category: "Comic voices",
    shortDescription: "Deadpan robot wit.",
    longDescription: "A low-emotion comedy voice built for dry punchlines and understated reactions.",
    toneTags: ["deadpan", "robot", "dry"],
    idealUseCases: ["dry jokes", "commentary"],
    energyLevel: 2, warmthLevel: 2, humorLevel: 5, roboticnessLevel: 5, clarityLevel: 4, authorityLevel: 3,
    defaultSpeed: 46, defaultPitch: 35, defaultVolume: 72, recommendedEmotion: 50,
    compatiblePersonalities: ["snark"],
    recommendedPersonalities: ["snark"],
    sampleLine: "I am thrilled. My circuits are doing a tiny parade.",
    featured: false, providerVoiceId: undefined, availability: "profile-only", accent: "green",
    timbreSource: "profile-only", cadenceProfile: "deadpan", fallbackBehavior: "browser-only",
    stylePrompt: "Deadpan robot wit. Flat affect, microscopic pauses where a normal voice would smile, never lift the pitch.",
    uniquenessExplanation: "Profile-only persona — no provider voice bound. Local engines style pitch, rate and cadence; timbre matches the local engine in use.",
  },
  {
    id: "arcade-announcer",
    name: "Arcade Announcer",
    category: "Retro / arcade voices",
    shortDescription: "Cabinet announcer with big score energy.",
    longDescription: "A punchy retro announcer for scores, wins, losses, and game starts.",
    toneTags: ["announcer", "retro", "score"],
    idealUseCases: ["games", "scoreboards"],
    energyLevel: 5, warmthLevel: 3, humorLevel: 4, roboticnessLevel: 3, clarityLevel: 4, authorityLevel: 4,
    defaultSpeed: 78, defaultPitch: 64, defaultVolume: 82, recommendedEmotion: 84,
    compatiblePersonalities: ["gm", "hype"],
    recommendedPersonalities: ["gm"],
    sampleLine: "New challenger. Try not to blink.",
    featured: true, providerVoiceId: undefined, availability: "future-provider-target", accent: "orange",
    timbreSource: "styled-variant", cadenceProfile: "punchy", fallbackBehavior: "native-then-browser",
    stylePrompt: "Cabinet announcer. Shouted scoreboard phrasing, sharp consonants, exaggerated 'new challenger' fanfare.",
    uniquenessExplanation: "No provider voice yet bound. Local engines style this profile with punchy, shouted-scoreboard cadence and arcade phrasing.",
  },
  {
    id: "analog-ghost",
    name: "Analog Ghost",
    category: "Retro / arcade voices",
    shortDescription: "VHS-era spectral machine voice.",
    longDescription: "A fuzzy analog profile for eerie but playful narration and old-tech atmosphere.",
    toneTags: ["analog", "ghost", "vhs"],
    idealUseCases: ["spooky stories", "retro"],
    energyLevel: 2, warmthLevel: 2, humorLevel: 3, roboticnessLevel: 4, clarityLevel: 3, authorityLevel: 2,
    defaultSpeed: 42, defaultPitch: 35, defaultVolume: 72, recommendedEmotion: 48,
    compatiblePersonalities: ["story", "detective"],
    recommendedPersonalities: ["story"],
    sampleLine: "The tape was blank until it said your name.",
    featured: false, providerVoiceId: undefined, availability: "browser-preview", accent: "purple",
    timbreSource: "styled-variant", cadenceProfile: "drawn-out", fallbackBehavior: "native-then-browser",
    stylePrompt: "VHS spectral hiss. Long fade-outs at sentence ends, faint wow-and-flutter pacing, occasional swallowed syllables.",
    uniquenessExplanation: "No provider voice bound. Local engines style this profile with drawn-out, VHS-fade phrasing and spectral pacing.",
  },
  {
    id: "glitch-sprite",
    name: "Glitch Sprite",
    category: "Robotic / synthetic voices",
    shortDescription: "Small digital sprite with unstable sparkle.",
    longDescription: "A tiny synthetic sprite for quick reactions, game tips, and playful interface lines.",
    toneTags: ["sprite", "glitch", "playful"],
    idealUseCases: ["games", "reactions"],
    energyLevel: 4, warmthLevel: 3, humorLevel: 4, roboticnessLevel: 5, clarityLevel: 3, authorityLevel: 2,
    defaultSpeed: 76, defaultPitch: 88, defaultVolume: 72, recommendedEmotion: 80,
    compatiblePersonalities: ["chaos", "gm"],
    recommendedPersonalities: ["chaos", "gm"],
    sampleLine: "Ping. I found a tiny problem wearing a hat.",
    featured: false, providerVoiceId: undefined, availability: "browser-preview", accent: "pink",
    timbreSource: "styled-variant", cadenceProfile: "staccato", fallbackBehavior: "native-then-browser",
    stylePrompt: "Tiny digital sprite. Pixel-burst phrasing, exaggerated pitch jumps mid-word, occasional 'ping!' interjections.",
    uniquenessExplanation: "No provider voice bound. Local engines style this profile with high-pitched, pixel-burst phrasing and sprite-like interjections.",
  },
  {
    id: "little-lab-assistant",
    name: "Little Lab Assistant",
    category: "Warm assistants",
    shortDescription: "Curious junior scientist energy.",
    longDescription: "A bright assistant profile for experiments, learning, and playful science-flavored prompts.",
    toneTags: ["curious", "lab", "bright"],
    idealUseCases: ["learning", "experiments"],
    energyLevel: 4, warmthLevel: 5, humorLevel: 3, roboticnessLevel: 2, clarityLevel: 4, authorityLevel: 2,
    defaultSpeed: 68, defaultPitch: 76, defaultVolume: 74, recommendedEmotion: 72,
    compatiblePersonalities: ["friendly", "wizard"],
    recommendedPersonalities: ["friendly", "wizard"],
    sampleLine: "Hypothesis: this is fixable and slightly cool.",
    featured: false, providerVoiceId: undefined, availability: "future-provider-target", accent: "green",
    timbreSource: "styled-variant", cadenceProfile: "lilting", fallbackBehavior: "native-then-browser",
    stylePrompt: "Junior scientist enthusiasm. Curious upward turns, occasional 'oh!' beats before findings, never condescending.",
    uniquenessExplanation: "No provider voice yet bound. Local engines style this profile with curious-scientist lilt and 'aha' beats.",
  },
  {
    id: "drama-module",
    name: "Drama Module",
    category: "Dramatic / villainous voices",
    shortDescription: "Over-serious theatrical intensity.",
    longDescription: "A dramatic profile for mock monologues, story beats, and harmless melodrama.",
    toneTags: ["dramatic", "theater", "intense"],
    idealUseCases: ["stories", "villain lines"],
    energyLevel: 4, warmthLevel: 2, humorLevel: 4, roboticnessLevel: 2, clarityLevel: 4, authorityLevel: 4,
    defaultSpeed: 50, defaultPitch: 32, defaultVolume: 78, recommendedEmotion: 82,
    compatiblePersonalities: ["story", "gm"],
    recommendedPersonalities: ["story"],
    sampleLine: "Behold, the mildly dramatic consequence.",
    featured: false, providerVoiceId: undefined, availability: "future-provider-target", accent: "purple",
    timbreSource: "styled-variant", cadenceProfile: "drawn-out", fallbackBehavior: "native-then-browser",
    stylePrompt: "Theatrical intensity. Big inhale before each line, dramatic descent on final word, never break character.",
    uniquenessExplanation: "No provider voice yet bound. Local engines style this profile with theatrical pauses and dramatic descents.",
  },
  {
    id: "riff-reactor",
    name: "Riff Reactor",
    category: "Comic voices",
    shortDescription: "Improvisational joke engine.",
    longDescription: "A fast riffing voice for jokes, alternate phrasings, and quick playful spins.",
    toneTags: ["riff", "comic", "fast"],
    idealUseCases: ["jokes", "rewrites"],
    energyLevel: 4, warmthLevel: 3, humorLevel: 5, roboticnessLevel: 2, clarityLevel: 4, authorityLevel: 2,
    defaultSpeed: 72, defaultPitch: 60, defaultVolume: 76, recommendedEmotion: 78,
    compatiblePersonalities: ["chaos", "snark"],
    recommendedPersonalities: ["chaos", "snark"],
    sampleLine: "Give me a topic and I will make it everybody's problem.",
    featured: false, providerVoiceId: undefined, availability: "browser-preview", accent: "pink",
    timbreSource: "styled-variant", cadenceProfile: "staccato", fallbackBehavior: "native-then-browser",
    stylePrompt: "Stand-up riff energy. Quick pivots, callback phrasing, occasional self-interrupt before the punchline.",
    uniquenessExplanation: "No provider voice bound. Local engines style this profile with rapid pivots and stand-up callback phrasing.",
  },
  {
    id: "low-battery-philosopher",
    name: "Low Battery Philosopher",
    category: "Calm / reflective voices",
    shortDescription: "Sleepy machine wisdom at 4 percent.",
    longDescription: "A slow, amusingly profound profile for reflective lines and quiet jokes.",
    toneTags: ["sleepy", "philosophical", "dry"],
    idealUseCases: ["reflection", "quiet jokes"],
    energyLevel: 1, warmthLevel: 4, humorLevel: 4, roboticnessLevel: 4, clarityLevel: 3, authorityLevel: 2,
    defaultSpeed: 32, defaultPitch: 24, defaultVolume: 68, recommendedEmotion: 22,
    compatiblePersonalities: ["calm", "snark"],
    recommendedPersonalities: ["calm", "snark"],
    sampleLine: "At four percent, every thought becomes poetry.",
    featured: false, providerVoiceId: undefined, availability: "browser-preview", accent: "orange",
    timbreSource: "styled-variant", cadenceProfile: "drawn-out", fallbackBehavior: "native-then-browser",
    stylePrompt: "Battery at 4 percent. Slow-as-molasses pacing, long dropouts mid-clause, sleepy half-jokes, occasional sigh.",
    uniquenessExplanation: "No provider voice bound. Local engines style this profile with extreme slow pacing and sleepy half-jokes.",
  },
  {
    id: "packet-punk",
    name: "Packet Punk",
    category: "Robotic / synthetic voices",
    shortDescription: "Network gremlin energy with sharp edges.",
    longDescription: "A synthetic network-flavored voice for alerts, scans, and glitchy cyber commentary.",
    toneTags: ["network", "punk", "synthetic"],
    idealUseCases: ["network alerts", "scan flavor"],
    energyLevel: 4, warmthLevel: 2, humorLevel: 4, roboticnessLevel: 5, clarityLevel: 4, authorityLevel: 3,
    defaultSpeed: 66, defaultPitch: 42, defaultVolume: 76, recommendedEmotion: 76,
    compatiblePersonalities: ["chaos", "wizard"],
    recommendedPersonalities: ["chaos", "wizard"],
    sampleLine: "Packet lost. Attitude retained.",
    featured: false, providerVoiceId: undefined, availability: "browser-preview", accent: "green",
    timbreSource: "styled-variant", cadenceProfile: "staccato", fallbackBehavior: "native-then-browser",
    stylePrompt: "Cyber-punk packet gremlin. Sharp clipped phrasing, packet-loss stutter on technical words, attitude-laden 'whatever'.",
    uniquenessExplanation: "No provider voice bound. Local engines style this profile with clipped, packet-loss phrasing and punk attitude.",
  },
  {
    id: "void-oracle",
    name: "Void Oracle",
    category: "Dramatic / villainous voices",
    shortDescription: "Cryptic sci-fi prophecy tone.",
    longDescription: "A mysterious profile for lore, dramatic warnings, and strange futuristic flavor.",
    toneTags: ["oracle", "cryptic", "dark"],
    idealUseCases: ["stories", "dramatic prompts"],
    energyLevel: 2, warmthLevel: 2, humorLevel: 2, roboticnessLevel: 3, clarityLevel: 4, authorityLevel: 5,
    defaultSpeed: 36, defaultPitch: 18, defaultVolume: 76, recommendedEmotion: 48,
    compatiblePersonalities: ["story", "detective"],
    recommendedPersonalities: ["story", "detective"],
    sampleLine: "The quiet signal is usually the dangerous one.",
    featured: false, providerVoiceId: undefined, availability: "future-provider-target", accent: "purple",
    timbreSource: "styled-variant", cadenceProfile: "drawn-out", fallbackBehavior: "native-then-browser",
    stylePrompt: "Void oracle prophecy. Deep slow phrasing, dropped articles, riddle-style sentence shapes, never raise the voice.",
    uniquenessExplanation: "No provider voice yet bound. Local engines style this profile with deep, riddle-shaped phrasing and prophetic pacing.",
  },
]

function buildProfile(seed: ProfileSeed): VoiceProfile {
  const pitch = sliderToProfilePitch(seed.defaultPitch)
  const rate = sliderToProfileRate(seed.defaultSpeed)
  const toneProfile = inferToneProfile(seed.category, seed.toneTags, seed.energyLevel, seed.humorLevel, seed.roboticnessLevel)
  const uniquenessScore = computeUniquenessScore(seed, toneProfile)
  return {
    id: seed.id,
    displayName: seed.name,
    name: seed.name,
    pitch,
    rate,
    toneProfile,
    sampleText: seed.sampleLine,
    category: seed.category,
    shortDescription: seed.shortDescription,
    styleIdentity: seed.shortDescription,
    longDescription: seed.longDescription,
    toneTags: seed.toneTags,
    idealUseCases: seed.idealUseCases,
    energyLevel: seed.energyLevel,
    warmthLevel: seed.warmthLevel,
    humorLevel: seed.humorLevel,
    roboticnessLevel: seed.roboticnessLevel,
    clarityLevel: seed.clarityLevel,
    authorityLevel: seed.authorityLevel,
    defaultSpeed: seed.defaultSpeed,
    defaultPitch: seed.defaultPitch,
    defaultVolume: seed.defaultVolume,
    recommendedEmotion: seed.recommendedEmotion,
    compatiblePersonalities: seed.compatiblePersonalities,
    recommendedPersonalities: seed.recommendedPersonalities,
    sampleLine: seed.sampleLine,
    cadenceHint: inferCadenceHint(seed.cadenceProfile, toneProfile),
    cadenceProfile: seed.cadenceProfile,
    expressivenessLevel: inferExpressivenessLevel(seed.energyLevel, seed.humorLevel, toneProfile),
    featured: seed.featured,
    providerVoiceId: seed.providerVoiceId,
    availability: seed.availability,
    accent: seed.accent,
    timbreSource: seed.timbreSource,
    fallbackBehavior: seed.fallbackBehavior,
    uniquenessScore,
    uniquenessExplanation: seed.uniquenessExplanation,
    stylePrompt: seed.stylePrompt,
    emotionalInstructions: undefined,
  }
}

export const VOICE_PROFILES: VoiceProfile[] = PROFILE_SEEDS.map(buildProfile)

function inferCadenceHint(cadence: VoiceCadenceProfile, toneProfile: VoiceToneProfile) {
  switch (cadence) {
    case "clipped": return "Clipped phrasing, firm stops, decisive command rhythm."
    case "flowing": return "Smooth phrase joins, gentle transitions between clauses."
    case "punchy": return "Short bursts, big emphasis on key words, headline pacing."
    case "drawn-out": return "Long pauses, weighted final beats, cinematic stretch."
    case "staccato": return "Pixel-burst phrasing, sharp consonants, rapid stops."
    case "lilting": return "Bouncy ups-and-downs, melodic surprise beats."
    case "deadpan": return "Flat affect, microscopic pauses, no pitch lift on punchlines."
    default:
      return inferToneCadenceFallback(toneProfile)
  }
}

function inferToneCadenceFallback(toneProfile: VoiceToneProfile) {
  switch (toneProfile) {
    case "calm": return "Long pauses, gentle transitions, smoother sentence joins."
    case "energetic": return "Short beats, brisk pacing, momentum-first phrasing."
    case "aggressive": return "Clipped commands, firm stops, decisive cadence."
    case "robotic": return "Metered timing, tighter pauses, precision rhythm."
    case "dramatic": return "Slow lead-ins, weighted pauses, cinematic rise/fall."
    case "retro": return "Punchy arcade tempo with concise chunks."
    case "playful": return "Bouncy pacing, surprise emphasis, playful punctuation."
    case "sarcastic": return "Dry timing, deliberate beats before punchlines."
    default: return "Balanced pacing with clear phrase boundaries."
  }
}

function computeUniquenessScore(seed: ProfileSeed, toneProfile: VoiceToneProfile) {
  // Base score by timbre source — provider-distinct >> native-distinct >> styled-variant >> profile-only
  let score = 50
  switch (seed.timbreSource) {
    case "provider-distinct": score = 92; break
    case "native-distinct": score = 78; break
    case "styled-variant": score = 56; break
    case "profile-only": score = 36; break
  }
  // Reward strong style differentiation (cadence, big pitch/rate excursions).
  const pitchOff = Math.abs(seed.defaultPitch - 50)
  const speedOff = Math.abs(seed.defaultSpeed - 50)
  score += Math.min(8, Math.round((pitchOff + speedOff) / 12))
  // Reward extreme cadences (more audible).
  if (["clipped", "punchy", "drawn-out", "staccato", "deadpan"].includes(seed.cadenceProfile)) {
    score += 3
  }
  if (toneProfile === "robotic" || toneProfile === "dramatic" || toneProfile === "sarcastic") score += 1
  return Math.max(0, Math.min(100, score))
}

function inferExpressivenessLevel(
  energyLevel: VoiceProfile["energyLevel"],
  humorLevel: VoiceProfile["humorLevel"],
  toneProfile: VoiceToneProfile,
): 1 | 2 | 3 | 4 | 5 {
  const base = Math.min(5, Math.max(1, Math.round((energyLevel + humorLevel) / 2)))
  if (toneProfile === "dramatic" || toneProfile === "playful" || toneProfile === "energetic") return Math.min(5, (base + 1)) as 1 | 2 | 3 | 4 | 5
  if (toneProfile === "calm" || toneProfile === "robotic") return Math.max(1, (base - 1)) as 1 | 2 | 3 | 4 | 5
  return base as 1 | 2 | 3 | 4 | 5
}

function sliderToProfilePitch(defaultPitch: number) {
  return clamp(Number((0.6 + (defaultPitch / 100) * 1.0).toFixed(2)), 0.6, 1.6)
}

function sliderToProfileRate(defaultSpeed: number) {
  return clamp(Number((0.7 + (defaultSpeed / 100) * 0.7).toFixed(2)), 0.7, 1.4)
}

function inferToneProfile(
  category: VoiceProfile["category"],
  toneTags: string[],
  energyLevel: VoiceProfile["energyLevel"],
  humorLevel: VoiceProfile["humorLevel"],
  roboticnessLevel: VoiceProfile["roboticnessLevel"],
): VoiceToneProfile {
  const text = `${category} ${toneTags.join(" ")}`.toLowerCase()
  if (text.includes("sarcastic") || text.includes("snark") || text.includes("deadpan") || text.includes("dry")) return "sarcastic"
  if (text.includes("villain") || text.includes("intense") || text.includes("punk")) return "aggressive"
  if (text.includes("calm") || text.includes("soft") || text.includes("reflective") || text.includes("sleepy")) return "calm"
  if (text.includes("retro") || text.includes("arcade") || text.includes("analog") || text.includes("vhs")) return "retro"
  if (text.includes("robot") || text.includes("synthetic") || text.includes("glitch") || roboticnessLevel >= 4) return "robotic"
  if (text.includes("dramatic") || text.includes("cinematic") || text.includes("oracle")) return "dramatic"
  if (energyLevel >= 5 || text.includes("hype") || text.includes("fast") || text.includes("cheer")) return "energetic"
  if (humorLevel >= 4 || text.includes("comic") || text.includes("playful")) return "playful"
  return "balanced"
}

function clamp(value: number, min: number, max: number) {
  return Math.min(max, Math.max(min, value))
}

export function getVoiceProfile(id: string) {
  return VOICE_PROFILES.find((voice) => voice.id === id) ?? VOICE_PROFILES[0]
}

export const VOICE_CATEGORIES = Array.from(new Set(VOICE_PROFILES.map((voice) => voice.category)))
export const VOICE_TONE_TAGS = Array.from(new Set(VOICE_PROFILES.flatMap((voice) => voice.toneTags))).sort()

// ----------------------------------------------------------------------------
// Module-load validation: every uniqueness claim must be self-consistent.
// ----------------------------------------------------------------------------

const duplicateVoiceIds = VOICE_PROFILES
  .filter((voice, index, list) => list.findIndex((v) => v.id === voice.id) !== index)
  .map((voice) => voice.id)
const duplicateVoiceNames = VOICE_PROFILES
  .filter((voice, index, list) => list.findIndex((v) => v.name.toLowerCase() === voice.name.toLowerCase()) !== index)
  .map((voice) => voice.name)
if (duplicateVoiceIds.length || duplicateVoiceNames.length) {
  throw new Error(
    `Duplicate voice profile entries detected. ids=[${duplicateVoiceIds.join(", ")}], names=[${duplicateVoiceNames.join(", ")}]`,
  )
}

const providerVoiceOwnership = new Map<string, string>()
for (const voice of VOICE_PROFILES) {
  if (!voice.providerVoiceId) continue
  if (voice.timbreSource === "provider-distinct") {
    const previousOwner = providerVoiceOwnership.get(voice.providerVoiceId)
    if (previousOwner && previousOwner !== voice.id) {
      throw new Error(
        `Voice "${voice.id}" claims provider-distinct timbre on providerVoiceId="${voice.providerVoiceId}" but that voice ID is already owned by "${previousOwner}".`,
      )
    }
    providerVoiceOwnership.set(voice.providerVoiceId, voice.id)
  }
}
for (const voice of VOICE_PROFILES) {
  if (voice.providerVoiceId && voice.timbreSource !== "provider-distinct" && !providerVoiceOwnership.has(voice.providerVoiceId)) {
    // Allow a styled-variant to exist before its owner only if no owner is ever declared elsewhere.
    // Loop again to verify — if no provider-distinct owner exists at all, the styled-variant is fine.
    const anyOwner = VOICE_PROFILES.some(
      (other) => other.providerVoiceId === voice.providerVoiceId && other.timbreSource === "provider-distinct",
    )
    if (!anyOwner) {
      // Not strictly invalid (no false claim), but record that this provider voice has no canonical owner.
      // We do not throw — styled variants without an owner still describe truthful styled-variant behavior.
    }
  }
}
