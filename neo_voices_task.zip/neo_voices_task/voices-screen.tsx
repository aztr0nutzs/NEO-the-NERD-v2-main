        <div className="mt-4 rounded-lg bg-black/40 p-3" style={{ boxShadow: "inset 0 0 0 1px rgba(255,255,255,0.08)" }}>
          <div className="flex items-center justify-between">
            <p className="ps-mono text-[9px] uppercase tracking-[0.24em] text-white/45">Uniqueness model</p>
            <span
              className="rounded-full px-2 py-0.5 ps-mono text-[9px] tracking-[0.2em]"
              style={{
                color: uniqueness.isDistinctTimbre ? "#39ff14" : uniqueness.isProfileOnly ? "rgba(255,255,255,0.6)" : "#ff7a00",
                boxShadow: `inset 0 0 0 1px ${uniqueness.isDistinctTimbre ? "rgba(57,255,20,0.55)" : uniqueness.isProfileOnly ? "rgba(255,255,255,0.25)" : "rgba(255,122,0,0.55)"}`,
              }}
            >
              {timbreSourceLabel(voice)} · SCORE {voice.uniquenessScore}
            </span>
          </div>
          <p className="mt-2 text-xs text-white/80">{voice.uniquenessExplanation}</p>
          <p className="mt-2 ps-mono text-[10px] uppercase tracking-[0.22em] text-white/55">
            What changes:
          </p>
          <p className="mt-1 text-xs text-white/75">{uniqueness.whatChanges}</p>
          <p className="mt-2 ps-mono text-[10px] uppercase tracking-[0.22em] text-white/55">
            Style delta:
          </p>
          <p className="mt-1 text-xs text-white/70">{styleDelta}</p>
          <p className="mt-2 ps-mono text-[10px] uppercase tracking-[0.22em] text-white/55">
            Runtime path:
          </p>
          <p className="mt-1 text-xs text-white/70">
            {uniqueness.resolvedEngine === "provider"
              ? `Provider TTS (${voice.providerVoiceId})`
              : uniqueness.resolvedEngine === "native-android"
                ? "Android native TextToSpeech"
                : uniqueness.resolvedEngine === "browser-speech"
                  ? "Browser SpeechSynthesis"
                  : "Unavailable on this runtime"}
            {" · Fallback: "}
            {voice.fallbackBehavior.replace(/-/g, " ")}
          </p>
        </div>
