import type { VoiceParams } from "@/lib/types"
import type { VoiceCadenceProfile, VoiceProfile, VoiceToneProfile } from "./types"

/**
 * Engine-ready speech payload derived from a voice profile + the user's live
 * VoiceParams sliders. The numeric fields are normalized to ranges that every
 * speech surface accepts directly:
 *   - browser SpeechSynthesisUtterance (rate 0.1-10, pitch 0-2, volume 0-1)
 *   - Android native TextToSpeech bridge (1.0 = normal rate/pitch, volume 0-1)
 *   - OpenAI TTS (rate is re-clamped to 0.25-4 by ttsClient)
 */
export interface StyledVoiceSpeech {
  text: string
  rate: number
  pitch: number
  volume: number
}

function clamp(value: number, min: number, max: number) {
  return Math.min(max, Math.max(min, value))
}

// Inverse of voiceProfileToParams(): speed slider 0-100 -> engine rate 0.7-1.4
function speedSliderToRate(speed: number) {
  return 0.7 + (clamp(speed, 0, 100) / 100) * 0.7
}

// Inverse of voiceProfileToParams(): pitch slider 0-100 -> engine pitch 0.6-1.6
function pitchSliderToPitch(pitch: number) {
  return 0.6 + (clamp(pitch, 0, 100) / 100) * 1.0
}

// Subtle per-tone nudge so the same slider values still "read" as the profile
// they belong to. Kept small so user slider intent always dominates.
const TONE_RATE_NUDGE: Record<VoiceToneProfile, number> = {
  balanced: 0,
  energetic: 0.08,
  calm: -0.08,
  robotic: -0.02,
  aggressive: 0.05,
  sarcastic: -0.03,
  dramatic: -0.06,
  retro: 0.02,
  playful: 0.05,
}

const TONE_PITCH_NUDGE: Record<VoiceToneProfile, number> = {
  balanced: 0,
  energetic: 0.06,
  calm: -0.05,
  robotic: -0.08,
  aggressive: -0.04,
  sarcastic: 0.03,
  dramatic: -0.06,
  retro: 0.04,
  playful: 0.07,
}

// Cadence-driven rate/pitch deltas — these are *additional* on top of tone
// nudges, so a "punchy energetic" profile reads materially faster than a
// "drawn-out energetic" profile that shares the same tone.
const CADENCE_RATE_DELTA: Record<VoiceCadenceProfile, number> = {
  balanced: 0,
  clipped: 0.04,
  flowing: -0.02,
  punchy: 0.07,
  "drawn-out": -0.10,
  staccato: 0.10,
  lilting: 0.02,
  deadpan: -0.04,
}

const CADENCE_PITCH_DELTA: Record<VoiceCadenceProfile, number> = {
  balanced: 0,
  clipped: -0.03,
  flowing: 0,
  punchy: 0.02,
  "drawn-out": -0.04,
  staccato: 0.05,
  lilting: 0.06,
  deadpan: -0.05,
}

/**
 * Build the styled speech payload for a voice profile. Combines the user's
 * VoiceParams sliders with clamped tone + cadence nudges and per-profile
 * text shaping so the same engine voice still reads as a distinct profile.
 */
export function buildStyledVoiceSpeech(
  profile: VoiceProfile,
  text: string,
  params: VoiceParams,
): StyledVoiceSpeech {
  const baseSpoken =
    (text ?? "").trim() || profile.sampleLine || profile.sampleText || "NEO online."
  const spoken = shapeSpeechTextForProfile(profile, baseSpoken)

  const rate = clamp(
    speedSliderToRate(params.speed)
      + (TONE_RATE_NUDGE[profile.toneProfile] ?? 0)
      + (CADENCE_RATE_DELTA[profile.cadenceProfile] ?? 0),
    0.55,
    1.75,
  )
  const pitch = clamp(
    pitchSliderToPitch(params.pitch)
      + (TONE_PITCH_NUDGE[profile.toneProfile] ?? 0)
      + (CADENCE_PITCH_DELTA[profile.cadenceProfile] ?? 0),
    0.45,
    1.85,
  )
  const volume = clamp((params.volume ?? 75) / 100, 0, 1)

  return {
    text: spoken,
    rate: Number(rate.toFixed(2)),
    pitch: Number(pitch.toFixed(2)),
    volume: Number(volume.toFixed(2)),
  }
}

/**
 * Stronger per-profile text shaping. Applies to *every* preview, personality
 * test and spoken assistant response so the same engine voice reads
 * materially differently across profiles.
 */
export function shapeSpeechTextForProfile(profile: VoiceProfile, text: string) {
  const normalized = text.replace(/\s+/g, " ").trim()
  if (!normalized) return normalized

  // ----- ID-level overrides first (always win over cadence shaping) --------
  const idShaped = shapeById(profile.id, normalized)
  if (idShaped !== null) return idShaped

  // ----- Cadence-level shaping -------------------------------------------
  return shapeByCadence(profile.cadenceProfile, normalized)
}

function shapeById(id: string, text: string): string | null {
  switch (id) {
    case "commander":
      return text.replace(/\?$/g, ". Confirm.")
    case "tactical-guide":
      return text.replace(/\? /g, ". Move. ").replace(/\?$/g, ". Move.")
    case "prankster":
      return text.endsWith("!") ? `${text} ...probably.` : `${text}! ...probably.`
    case "tiny":
      return `${text} hehehehe.`
    case "droid":
      return `Unit ready. ${text}`
    case "friendly-tech-support":
      return text.startsWith("Let's") ? text : `Let's take this one step at a time. ${text}`
    case "arcade-announcer":
    case "hyperdrive-host":
      return `${text} — bonus round energy engaged!`
    case "circuit-cheerleader":
      return text.endsWith("!") ? `${text} You got this.` : `${text}! You got this.`
    case "midnight-narrator":
    case "deepcore":
      return `${text} ...and the room went quiet.`
    case "cosmic-commentator":
      return `Across the network: ${text}`
    case "villain":
      return `${text} ...mwhahaha.`
    case "void-oracle":
      return text.replace(/\. /g, "... ").replace(/, /g, "... ")
    case "drama-module":
      return `Behold — ${text}`
    case "glitch":
      return text.replace(/^(\w)/, "$1-$1")
    case "glitch-sprite":
      return `Ping. ${text}`
    case "packet-punk":
      return `${text} // packet retained.`
    case "analog-ghost":
      return `${text.replace(/\s/g, "... ")}`.replace(/\.{3,}\s*$/, "...")
    case "arcade":
      return text.replace(/^/, ">>> ").replace(/$/, " <<<")
    case "retro":
      return `Insert coin. ${text}`
    case "low-battery-philosopher":
      return text.replace(/\. /g, "... ").replace(/, /g, "... ")
    case "synth-sage":
      return text.replace(/, /g, " — ")
    case "dry-humor-unit":
      return text.replace(/!/g, ".")
    case "snark":
      return text.replace(/\.$/g, ".")
    case "smooth-operator":
      return text
    case "byte":
      return text
    case "neo":
    case "nova":
    case "neon-mentor":
    case "holo-host":
    case "hyper":
    case "overclock-coach":
    case "solar-diplomat":
    case "cyberkid":
    case "chill-byte":
    case "sparky":
    case "velvet-circuit":
    case "riff-reactor":
    case "little-lab-assistant":
      return null
    default:
      return null
  }
}

function shapeByCadence(cadence: VoiceCadenceProfile, text: string): string {
  switch (cadence) {
    case "clipped":
      // Add a beat after each comma; never extend ellipses.
      return text.replace(/, /g, ", ").replace(/!/g, ".")
    case "drawn-out":
      return text.replace(/\. /g, "... ").replace(/, /g, ", ... ")
    case "staccato":
      return text.replace(/, /g, ". ")
    case "punchy":
      return text.endsWith("!") || text.endsWith(".") ? text : `${text}!`
    case "deadpan":
      return text.replace(/!/g, ".")
    case "lilting":
      return text
    case "flowing":
      return text
    default:
      return text
  }
}

const TONE_INSTRUCTION: Record<VoiceToneProfile, string> = {
  balanced: "Speak with a clear, polished robot-companion tone.",
  energetic: "Speak with high energy, brisk pacing, and upbeat cyberpunk confidence.",
  calm: "Speak calmly and smoothly with relaxed, low-pressure pacing.",
  robotic: "Speak with a precise, lightly synthetic, evenly metered robotic tone.",
  aggressive: "Speak with sharp, forceful intensity while staying controlled.",
  sarcastic: "Speak with dry, deadpan wit and understated delivery.",
  dramatic: "Speak with cinematic gravity, deliberate pacing, and theatrical weight.",
  retro: "Speak with a nostalgic, arcade-flavored, slightly chiptune cadence.",
  playful: "Speak with a light, mischievous, playful bounce.",
}

const CADENCE_INSTRUCTION: Record<VoiceCadenceProfile, string> = {
  balanced: "Use even phrase boundaries and steady breathing.",
  clipped: "Use clipped phrasing, firm full stops, and short imperatives.",
  flowing: "Use smooth phrase joins, no abrupt breaks, gentle transitions.",
  punchy: "Use short bursts with strong emphasis on the key word in each clause.",
  "drawn-out": "Slow the delivery: long pauses, weighted final beats, cinematic stretch on long vowels.",
  staccato: "Use sharp consonants, rapid stops between short phrases, percussive timing.",
  lilting: "Use bouncy ups-and-downs in pitch, melodic surprise beats at clause ends.",
  deadpan: "Flat affect, microscopic pauses, never lift the pitch on punchlines.",
}

/**
 * Natural-language style instructions for provider TTS engines that accept an
 * `instructions` field (e.g. OpenAI gpt-4o-mini-tts). Combines tone, cadence
 * and the hand-tuned per-profile `stylePrompt` so styled-variant profiles
 * sounding very different from each other even when bound to the same
 * underlying provider voice.
 */
export function toneInstructions(profile: VoiceProfile): string {
  const tone = TONE_INSTRUCTION[profile.toneProfile] ?? TONE_INSTRUCTION.balanced
  const cadence = CADENCE_INSTRUCTION[profile.cadenceProfile] ?? CADENCE_INSTRUCTION.balanced
  const style = profile.stylePrompt ? ` ${profile.stylePrompt}` : ""
  const tags = profile.toneTags?.length ? ` Tone cues: ${profile.toneTags.join(", ")}.` : ""
  return `${tone} ${cadence}${style}${tags}`
}
