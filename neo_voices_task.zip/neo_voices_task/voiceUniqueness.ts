/**
 * Voice uniqueness helpers.
 *
 * Single source of truth for answering:
 *   - "Is this profile a genuinely distinct timbre?"
 *   - "Is this a styled variant?"
 *   - "What actually changes when this voice is selected?"
 *   - "What fallback occurs on the current runtime?"
 *
 * The static taxonomy lives on `VoiceProfile.timbreSource`. The runtime-truth
 * variant — which depends on whether provider TTS / native Android TTS is
 * actually available — is composed in `getRuntimeTimbreSource()`.
 */

import type { VoiceProfile, VoiceTimbreSource } from "./types"
import type { VoiceRuntimeCapabilities } from "./voice-runtime"

export type RuntimeTimbreSource =
  | VoiceTimbreSource
  | "browser-styled"
  | "device-voice"
  | "unavailable"

export interface UniquenessSummary {
  staticSource: VoiceTimbreSource
  runtimeSource: RuntimeTimbreSource
  isDistinctTimbre: boolean
  isStyledVariant: boolean
  isProfileOnly: boolean
  /** True iff the runtime can faithfully produce this profile's promised timbre. */
  isFullyRealized: boolean
  /** What changes when this voice is selected on this device, in one sentence. */
  whatChanges: string
  /** Which engine path will actually drive playback on this runtime. */
  resolvedEngine: "provider" | "native-android" | "browser-speech" | "none"
  uniquenessScore: number
  uniquenessExplanation: string
}

export function isDistinctTimbre(profile: VoiceProfile) {
  return profile.timbreSource === "provider-distinct" || profile.timbreSource === "native-distinct"
}

export function isStyledVariant(profile: VoiceProfile) {
  return profile.timbreSource === "styled-variant"
}

export function isProfileOnly(profile: VoiceProfile) {
  return profile.timbreSource === "profile-only"
}

export function describeStyleDelta(profile: VoiceProfile): string {
  // One concise line summarizing the styling deltas a user can hear.
  const parts: string[] = []
  if (profile.defaultPitch >= 70) parts.push("higher pitch")
  else if (profile.defaultPitch <= 35) parts.push("lower pitch")
  if (profile.defaultSpeed >= 70) parts.push("faster cadence")
  else if (profile.defaultSpeed <= 40) parts.push("slower cadence")
  parts.push(`${profile.cadenceProfile} phrasing`)
  if (profile.toneProfile !== "balanced") parts.push(`${profile.toneProfile} tone`)
  return parts.join(" · ")
}

export function getRuntimeTimbreSource(
  profile: VoiceProfile,
  capabilities: VoiceRuntimeCapabilities,
): RuntimeTimbreSource {
  if (profile.availability === "unavailable") return "unavailable"

  // Provider path takes precedence when the profile is mapped AND provider TTS is live.
  if (profile.availability === "provider-ready" && capabilities.providerTtsAvailable) {
    // provider-distinct, or styled-variant on top of a distinct provider voice.
    return profile.timbreSource === "provider-distinct" ? "provider-distinct" : "styled-variant"
  }

  // Native Android path.
  if (capabilities.nativeAndroidTtsAvailable) {
    if (capabilities.selectedAndroidVoiceName && capabilities.nativeAndroidVoiceCount > 1) {
      return "device-voice"
    }
    return "styled-variant"
  }

  // Browser fallback.
  if (capabilities.browserSpeechSupported) return "browser-styled"

  return "unavailable"
}

function resolveEngine(
  profile: VoiceProfile,
  capabilities: VoiceRuntimeCapabilities,
): UniquenessSummary["resolvedEngine"] {
  if (profile.availability === "unavailable") return "none"
  if (profile.availability === "provider-ready" && capabilities.providerTtsAvailable) return "provider"
  if (capabilities.nativeAndroidTtsAvailable) return "native-android"
  if (capabilities.browserSpeechSupported) return "browser-speech"
  return "none"
}

function describeWhatChanges(
  profile: VoiceProfile,
  runtimeSource: RuntimeTimbreSource,
  engine: UniquenessSummary["resolvedEngine"],
): string {
  switch (engine) {
    case "provider": {
      if (profile.timbreSource === "provider-distinct") {
        return `Switches to a genuinely distinct provider voice (${profile.providerVoiceId}) with this profile's style prompt applied.`
      }
      return `Same provider voice (${profile.providerVoiceId}) as its family, but cadence, pitch, rate, and provider style prompt change.`
    }
    case "native-android": {
      if (runtimeSource === "device-voice") {
        return "Selects a different Android engine voice plus this profile's pitch, rate, and text shaping."
      }
      return "Applies this profile's pitch, rate, cadence and text shaping to the Android engine's default voice."
    }
    case "browser-speech":
      return "Applies this profile's pitch, rate, cadence and text shaping to the browser SpeechSynthesis voice."
    case "none":
    default:
      return "Profile metadata only — no audio playback available in this runtime."
  }
}

export function summarizeUniqueness(
  profile: VoiceProfile,
  capabilities: VoiceRuntimeCapabilities,
): UniquenessSummary {
  const runtimeSource = getRuntimeTimbreSource(profile, capabilities)
  const engine = resolveEngine(profile, capabilities)
  const isFullyRealized =
    (profile.timbreSource === "provider-distinct" && engine === "provider") ||
    (profile.timbreSource === "native-distinct" && engine === "native-android") ||
    (profile.timbreSource === "styled-variant" && engine !== "none") ||
    (profile.timbreSource === "profile-only" && engine !== "none")

  return {
    staticSource: profile.timbreSource,
    runtimeSource,
    isDistinctTimbre: isDistinctTimbre(profile),
    isStyledVariant: isStyledVariant(profile),
    isProfileOnly: isProfileOnly(profile),
    isFullyRealized,
    whatChanges: describeWhatChanges(profile, runtimeSource, engine),
    resolvedEngine: engine,
    uniquenessScore: profile.uniquenessScore,
    uniquenessExplanation: profile.uniquenessExplanation,
  }
}

/** Compact badge label for cards / lists. */
export function timbreBadgeLabel(
  source: VoiceTimbreSource | RuntimeTimbreSource,
): { label: string; tone: "distinct" | "variant" | "device" | "fallback" | "off" } {
  switch (source) {
    case "provider-distinct":
      return { label: "UNIQUE TIMBRE · PROVIDER", tone: "distinct" }
    case "native-distinct":
      return { label: "UNIQUE TIMBRE · DEVICE", tone: "distinct" }
    case "device-voice":
      return { label: "DEVICE VOICE", tone: "device" }
    case "styled-variant":
      return { label: "STYLED VARIANT", tone: "variant" }
    case "browser-styled":
      return { label: "BROWSER · STYLED", tone: "fallback" }
    case "profile-only":
      return { label: "PROFILE ONLY", tone: "variant" }
    case "unavailable":
      return { label: "UNAVAILABLE", tone: "off" }
    default:
      return { label: "STYLED VARIANT", tone: "variant" }
  }
}
